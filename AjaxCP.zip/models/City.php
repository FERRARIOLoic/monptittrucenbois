<?php

require_once(dirname(__FILE__).'/../utils/Database.php');

class City{

    /**
     * Méthode permettant de trouver la liste des villes en fonction d'un code postal
     * 
     * @param string $zipcode
     * 
     * @return array
     */
    public static function getByZip(string $zipcode): array{

        $pdo = Database::getInstance();
        $sql = 'SELECT `id`, `name` FROM `cities` 
            WHERE `zipcode` LIKE :zipcode;';

        $sth = $pdo->prepare($sql);

        $sth->bindValue(':zipcode',"%$zipcode%");
        $sth->execute();
        return($sth->fetchAll());

    }
}