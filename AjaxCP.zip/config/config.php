<?php
/**============================================================*
 * Ceci est un fichier de configuration pour la base de donnée * 
 * =========================================================== *
 * This is a configuration file for the database               *
===============================================================*/
//--------------------------------------------------------------/

/**============================================================*
 * Nom d'utilisateur de la base de donnée                      *
 * =========================================================== *
 * Username of Database                                        *
 ==============================================================*/
define('LOGIN', 'root');

/**============================================================*
 * Mot de passe de la base de donnée                           *
 * =========================================================== *
 * Password of database                                        *
 ==============================================================*/
define('PASSWORD', '');

/**============================================================*
 * DSN Complet pour le fichier Database                          *
 * =========================================================== *
 * DSN for database file                                        *
 ==============================================================*/

// La base est en UTF8, il faut donc le préciser dans le DSN pour éviter les problèmes de caractères spéciaux
define('DSN', 'mysql:host=localhost;dbname=dwwm_ajaxcp;charset=UTF8');