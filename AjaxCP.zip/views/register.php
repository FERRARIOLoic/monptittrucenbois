<div class="row">
    <div class="col">
        <form action="" method="post" id="myForm">
            <div class="input-group mt-5">
            
                <span class="input-group-text">Code postal</span>
                <input
                    class="form-control form-control-lg"
                    maxlength="5"
                    type="text"
                    placeholder="Entrez un code postal"
                    name="zipcode"
                    id="zipcode"
                >
                
                
                
                <select class="form-select form-select-lg" name="city" id="city">
                    <option selected>Ville...</option>
                </select>

            </div>
        </form>

    </div>
</div>

<script src="../public/assets/js/city.js"></script>