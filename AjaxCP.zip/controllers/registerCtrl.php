<?php
// On charge le modèle qui nous servira à interroger la BDD
require_once(dirname(__FILE__).'/../models/City.php');

// Récupération et nettoyage du paramètre 'ajaxCP' permettant d'identifier la requête Ajax

$ajax = filter_input(INPUT_POST, 'ajax', FILTER_VALIDATE_BOOLEAN);

// Traitement ajax uniquement!!!
if( $_SERVER['REQUEST_METHOD'] == 'POST' && $ajax){
    // Récupération et nettoyage du champs de formulaire 'ville_code_postal'
    $zipcodeAjax = trim(filter_input(INPUT_POST,'zipcodeAjax', FILTER_SANITIZE_SPECIAL_CHARS));
    // Appel à la méthode qui retourne un tableau d'objets {ville_id, ville_nom_reel}
    $cities = City::getByZip($zipcodeAjax);
    // On json le résultat pour pourvoir le traiter comme un objet en javascript
    echo json_encode($cities);
    // On arrete tout traitement ici die, ou exit ;)
    exit;
}

include(dirname(__FILE__).'/../views/templates/header.php');
    include(dirname(__FILE__).'/../views/register.php');
include(dirname(__FILE__).'/../views/templates/footer.php');