<?php

header('location: /controllers/registerCtrl.php');
exit;