<?php

include(dirname(__FILE__) . '/../config/config.php');

$upload_dir = dirname(__FILE__) . '/../uploads/users';

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    // L'idéal serait de créer une fonction qui gère l'enregistrement sur le serveur
    if($_FILES['profile'] && $_FILES['profile']['error']==0){

        try {
            
            if($_FILES['profile']['size'] > LIMIT_WEIGHT){
                throw new Exception('Poids dépassé');
            }

            if(!in_array($_FILES['profile']['type'], SUPPORTED_FORMAT)){
                throw new Exception('Format non autorisé');
            }

            $originalImage = $upload_dir.'/original.jpg';
            if (!move_uploaded_file($_FILES['profile']['tmp_name'], $originalImage)) {
                throw new Exception('Problème lors de l\'enregistrement');
            }

            $src_width = getimagesize($originalImage)[0];
            $src_height = getimagesize($originalImage)[1];
            $dst_width = 400;
            $dst_height = $dst_width*$src_height/$src_width;
            $ressourceDestination = imagecreatetruecolor($dst_width, $dst_height);
            $ressourceOriginal = imagecreatefromjpeg($originalImage);

            // Redimensionne
            imagecopyresampled($ressourceDestination,$ressourceOriginal,0,0,0,0,$dst_width,$dst_height,$src_width,$src_height);
            
            // Sauvegarde l'image redimensionnée
            $resampledDestination = $upload_dir.'/resampled.jpg';
            imagejpeg($ressourceDestination, $resampledDestination,75);

            // Recadre
            $ressourceOriginal = imagecreatefromjpeg($resampledDestination);
            $ressourceCropped = imagecrop($ressourceOriginal, ['x' => 0, 'y' => 0, 'width' => 400, 'height' => 400]);

            // Sauvegarde l'image recadrée
            $croppedDestination = $upload_dir.'/cropped.jpg';
            imagejpeg($ressourceCropped, $croppedDestination,75);

        } 
        catch(\Exception $ex){
            echo($ex->getMessage());
        }
    }

}


include(dirname(__FILE__) . '/../views/profile.php');