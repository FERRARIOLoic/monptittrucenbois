<?php
// Constante limite de taille upload
define('LIMIT_WEIGHT', 2*1024*1024);
define('SUPPORTED_FORMAT', array('image/jpeg', 'image/png'));
define('MIN_WIDTH', 200);
define('MIN_HEIGHT', 200);