<?php

define('ALLOWED_IMG_TYPES', array('image/jpeg', 'image/png'));
define('MAX_SIZE', 2 * 1024 * 1024);


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {

        if (!isset($_FILES['fic'])) {
            throw new Exception('input non transmis');
        }

        $fic = $_FILES['fic'];
        if ($fic['error'] == 4) {
            throw new Exception('image manquante');
        }

        if ($fic['error'] > 0) {
            throw new Exception('une erreur lors du transfert');
        }

        if (!in_array(strtolower($fic['type']), ALLOWED_IMG_TYPES)) {
            throw new Exception('Format non autorisé');
        }

        if ($fic['size'] > MAX_SIZE) {
            throw new Exception('Poids max atteint');
        }

        $id = 12;
        $from = $fic['tmp_name'];
        $extension = pathinfo($fic['full_path'], PATHINFO_EXTENSION);
        $to = __DIR__ . '/uploads/' . $id . '.' . $extension;
        if (!move_uploaded_file($from, $to)) {
            throw new Exception('Image non enregistrée');
        }

        $sizes = getimagesize($to);
        $src_width = $sizes[0];
        $src_height = $sizes[1];

        if ($src_width > $src_height) {
            $height = 200;
            $width = intval($src_width / $src_height * $height);
        } else {
            $width = 200;
            $height = intval($src_height / $src_width * $width);
        }



        $dst_image = imagecreatetruecolor($width, $height);
        $src_image = imagecreatefromjpeg($to);
        $dst_x = 0;
        $dst_y = 0;
        $src_x = 0;
        $src_y = 0;
        $dst_width = $width;
        $dst_height = $height;

        if (!imagecopyresampled(
            $dst_image,
            $src_image,
            $dst_x,
            $dst_y,
            $src_x,
            $src_y,
            $dst_width,
            $dst_height,
            $src_width,
            $src_height
        )) {
            throw new Exception('problème lors du redimensionnement');
        };

        $toResampled = __DIR__ . '/uploads/resampled_' . $id . '.' . $extension;

        if (!imagejpeg($dst_image, $toResampled)) {
            throw new Exception('problème lors de l\'enregistrement de l\'image redimensionnée');
        }

        $widthCropped = 200;
        $heightCropped = 200;

        if ($src_width > $src_height) {
            $x = ($dst_width - $widthCropped) / 2;
            $y = 0;
        } else {
            $x = 0;
            $y = ($dst_height - $heightCropped) / 2;
        }

        
        $imgRessourceCropped = imagecrop($dst_image, ['x' => $x, 'y' => $y, 'width' => $widthCropped, 'height' => $heightCropped]);

        $toCropped = __DIR__ . '/uploads/cropped_' . $id . '.' . $extension;

        if (!imagejpeg($imgRessourceCropped, $toCropped)) {
            throw new Exception('problème lors de l\'enregistrement de l\'image redimensionnée');
        }
    } catch (\Exception $ex) {
        $error = $ex->getMessage();
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?= $error ?? '' ?>


    <form method="post" enctype="multipart/form-data">

        <input type="file" name="fic">
        <button type="submit">Enregistrer</button>

    </form>

    <img src="/uploads/resampled_<?= $id ?>.<?= $extension ?>">


</body>

</html>